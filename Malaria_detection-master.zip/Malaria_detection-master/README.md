# Malaria_detection

dataset:https://www.kaggle.com/iarunava/cell-images-for-detecting-malaria

cells.npy can made by using malaria.ipynb

Malaria.ipynb contains normal CNN architecture 3-layer and 7-layer

I Have also applied VGG16, ResNet, Inception Network.



